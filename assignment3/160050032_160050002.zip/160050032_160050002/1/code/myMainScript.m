%% MyMainScript

tic;
%% Your code here
    myHarrisCornerDetector();
toc;

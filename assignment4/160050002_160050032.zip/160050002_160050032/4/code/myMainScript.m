%% Custom SVD implementation
tic;
A = ones(112,333);
[U,S,V] = MySVD(A);
% Verify result ignoring precision errors
if max(real(U*S*V') - A) < 1e-6
    disp('SVD successful.');
end
toc;
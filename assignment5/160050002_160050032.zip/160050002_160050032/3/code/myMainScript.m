%% MyMainScript

tic;
%% Your code here
    MyNotchFilter('../data/image_low_frequency_noise.mat');
toc;
